#!/bin/sh

# Copyright (c) Good Technology, 2011. All rights reserved.
# Install the GD SDK to Xcode and iOS SDKs.

# When invoked from the Installer, the chosen installation volume and 
# directory is passed as the 2nd argument. If no arguments,
# the script is assumed to be being invoked by the user.
if [ "$2" ]; then
  # Invoked from Installer. Remove any prior SDK and extract the new one...
  GD_ROOT="$2"
  GD_DIR="${GD_ROOT}"/Good.platform
  rm -rf "${GD_DIR}"
  mkdir -p "${GD_DIR}"
  echo Extracting payload to "${GD_DIR}"...
  tar -C "${GD_ROOT}" -xf "${GD_ROOT}"/Good.platform.tar
  echo Payload extracted.
  rm -f "${GD_ROOT}"/Good.platform.tar
  chown -R `whoami` "${GD_ROOT}"
  chmod -R a=rwx "${GD_ROOT}"

  # install extensions, if any
  "${GD_DIR}"/install_extensions.sh "${GD_ROOT}"
  
else
  GD_DIR=`dirname "$(cd ${0%/*} && echo $PWD/${0##*/})"`

  # unpacking FIPS module
  "${GD_DIR}"/install_extensions.sh "${GD_DIR}" ManualInstallationFlag
fi

# Uninstall any prior Xcode installation or exit if Xcode is not found
"${GD_DIR}"/uninstall.sh $*
if [ $? -ne 0 ]; then
    exit 1
fi

echo Installing...

# Xcode SDK paths
SELECTED_SDK_DIR=`xcode-select -print-path`
SDK_DIR="${SELECTED_SDK_DIR}"/Platforms/iPhone
SDK_DEV_DIR="${SDK_DIR}"OS.platform/Developer/SDKs
SDK_SIM_DIR="${SDK_DIR}"Simulator.platform/Developer/SDKs

XCODE_APP=.app
if [[ "${SELECTED_SDK_DIR}" == *"$XCODE_APP"* ]]; then
	XCODE_APP_DIR=`expr "${SELECTED_SDK_DIR}" :  '\(.*\.app\)'`
else
	XCODE_APP_DIR="${SELECTED_SDK_DIR}"/Applications/Xcode.app
fi
if [ -d "${XCODE_APP_DIR}" ]; then
	#at some point 'version.plist' changed its name to begin with a lowercase 'v'
	#in a case-sensitive volume this makes a big difference
	VERSION_PLIST_CASE_SENSITIVE_NAME='version'
	if [ -f "${XCODE_APP_DIR}"/Contents/Version ]; then
		VERSION_PLIST_CASE_SENSITIVE_NAME='Version'
	fi
    XCODE_VER=`defaults read "${XCODE_APP_DIR}"/Contents/"${VERSION_PLIST_CASE_SENSITIVE_NAME}" CFBundleShortVersionString`
    echo Detected Xcode version ${XCODE_VER}
    if [ `expr ${XCODE_VER:0:1}` -eq 6 ]; then
        echo Installing Xcode templates for 6.x....
        GD_TEMPLATE_DIR="${GD_DIR}"/Templates/6.x/
        SDK_TEMPLATE_DIR="${SDK_DIR}"OS.platform/Developer/Library/Xcode/Templates/Project\ Templates/iOS/Application
        cp -R "${GD_TEMPLATE_DIR}"/* "${SDK_TEMPLATE_DIR}"/
    elif [ `expr ${XCODE_VER:0:1}` -eq 7 ]; then
        echo Installing Xcode templates for 7.x....
        GD_TEMPLATE_DIR="${GD_DIR}"/Templates/7.x/
        SDK_TEMPLATE_DIR="${SDK_DIR}"OS.platform/Developer/Library/Xcode/Templates/Project\ Templates/iOS/Application
        cp -R "${GD_TEMPLATE_DIR}"/* "${SDK_TEMPLATE_DIR}"/   
    else
        echo GD templates are only supported on Xcode 6.x or 7.x versions. Skipping template installation.
        #if you want to bail out completely, uncomment the following two lines...
        echo This version of Xcode is not supported.
        exit 1
    fi
fi

shopt -s expand_aliases

#echo Installing API Reference documentation...
GD_DOCSET="${GD_DIR}"/Documents/com.good.gd.docset
SYSTEM_DOCSET=~/Library/Developer/Shared/Documentation/DocSets/com.good.gd.docset

#create dir if non-existent - fresh xcode install
if [ ! -d "${SYSTEM_DOCSET}" ]; then
    mkdir -p "${SYSTEM_DOCSET}";
fi

cp -R "${GD_DOCSET}"/* "${SYSTEM_DOCSET}"/

# Documentation cannot be viewed in Xcode (See Apple Developer bug 8900323).
# In the interim, refer to the API Reference at https://developer.good.com.
#cp -R "${GD_DOCSET_DIR}"/* "${SDK_DOCSET_DIR}"/

echo Installing static frameworks...
GD_FRAMEWRK_DIR="${GD_DIR}"/Frameworks
SDK_FRAMEWRK_DIR=System/Library/Frameworks
for sub_dir in $(ls "${SDK_DEV_DIR}")
do
  cp -R "${GD_FRAMEWRK_DIR}"/* "${SDK_DEV_DIR}"/"${sub_dir}"/"${SDK_FRAMEWRK_DIR}"/
done
for sub_dir in $(ls "${SDK_SIM_DIR}")
do
  cp -R "${GD_FRAMEWRK_DIR}"/* "${SDK_SIM_DIR}"/"${sub_dir}"/"${SDK_FRAMEWRK_DIR}"/
done

echo Installation complete.
