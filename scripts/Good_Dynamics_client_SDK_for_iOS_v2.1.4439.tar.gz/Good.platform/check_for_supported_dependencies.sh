#!/bin/sh
# Copyright (c) Good Technology, 2011. All rights reserved.
# Checks if Xcode 4.2 or 4.3 is installed and selected.

# Since Xcode 4.3, the iOS SDK has moved to /Applications/Xcode.app
XCODE_APP_DIR=/Applications/Xcode.app
XCODE_DEV_DIR=/Applications/Xcode.app/Contents/Developer

if [ ! -d "${XCODE_DEV_DIR}" ]; then
    # Probably a legacy installation under /Developer.
    XCODE_DEV_DIR=`xcode-select -print-path`
	XCODE_APP=.app
	if [[ "${XCODE_DEV_DIR}" == *"$XCODE_APP"* ]]; then
		XCODE_APP_DIR=`expr "${XCODE_DEV_DIR}" :  '\(.*\.app\)'`
	else
		XCODE_APP_DIR=${XCODE_DEV_DIR}/Applications/Xcode.app
	fi
fi

if [ -d "${XCODE_DEV_DIR}" ]; then
    # Make sure it really is switched as other installation scripts depend on this.
    CHECK_XCODE_DEV_DIR=`xcode-select -print-path`
	XCODE_APP=.app
	if [[ "${CHECK_XCODE_DEV_DIR}" == *"$XCODE_APP"* ]]; then
		XCODE_APP_DIR=`expr "${XCODE_DEV_DIR}" :  '\(.*\.app\)'`
		XCODE_DEV_DIR=${CHECK_XCODE_DEV_DIR}
	else
    	xcode-select -switch "${XCODE_DEV_DIR}" 
	fi

    #at some point 'version.plist' changed its name to begin with a lowercase 'v'
    #in a case-sensitive volume this makes a big difference
    VERSION_PLIST_CASE_SENSITIVE_NAME='version'
    if [ -f "${XCODE_APP_DIR}"/Contents/Version ]; then
    VERSION_PLIST_CASE_SENSITIVE_NAME='Version'
    fi

    # Now locate xcode
    XCODE_VER=`defaults read "${XCODE_APP_DIR}"/Contents/"${VERSION_PLIST_CASE_SENSITIVE_NAME}" CFBundleShortVersionString`
	XCODE_MAJOR_VER=`expr ${XCODE_VER:0:1}`
	XCODE_MINOR_VER=`expr ${XCODE_VER:2:1}`
	
	# Only Xcode 4.2.x or higher is supported...
	if (( XCODE_MAJOR_VER == 4 )); then
		if (( XCODE_MINOR_VER == 2 )); then
		   echo "Xcode 4.2 is selected: `xcode-select -print-path`."
		   exit 1
		fi
		if (( XCODE_MINOR_VER > 2 )); then
		   echo "Xcode 4.3 or higher is selected: `xcode-select -print-path`."
		   exit 1
		fi
	fi
	if (( XCODE_MAJOR_VER > 4 )); then
		echo "Xcode > 4 is selected: `xcode-select -print-path`."
		exit 1
	fi
fi

echo Install or select Xcode 4.2.x or higher.
echo To check which Xcode IDE is selected, run xcode-select -print-path from the command line.
echo If xcode-select is not found, then it is likely that Xcode and iOS SDK has not been installed.
echo For Xcode 4.3 or higher from the AppStore xcode-select can be set as follows:
echo sudo xcode-select -switch /Applications/Xcode.app/Contents/Developer/
exit 0
