#!/bin/sh

# Copyright (c) Good Technology, 2011. All rights reserved.
# Remove artifacts from v0.5.1743 and older, and unintsall the GD SDK from Xcode.

# When invoked from the Installer, the chosen installation volume and 
# directory is passed as the 2nd argument. If no arguments,
# the script is assumed to be being invoked by the user.
if [ "$2" ]; then
  # Invoked from Installer.
  GD_DIR="."
else
  GD_DIR=`dirname "$(cd "${0%/*}" && echo $PWD/${0##*/})"`
fi

# Exit if Xcode is not found
"${GD_DIR}"/check_for_supported_dependencies.sh $*
if [ $? -eq 0 ]; then
    exit 1
fi

if [[ $UID != 0 ]]; then
    echo "Please run this script with sudo:"
    echo "sudo $0 $*"
    exit 1
fi

echo Cleaning...

# Xcode SDK paths
SELECTED_SDK_DIR=`xcode-select -print-path`
SDK_DIR="${SELECTED_SDK_DIR}"/Platforms/iPhone
SDK_DEV_DIR="${SDK_DIR}"OS.platform/Developer/SDKs
SDK_SIM_DIR="${SDK_DIR}"Simulator.platform/Developer/SDKs

# Remove artifacts from v0.5.1743 and older
rm -rf ~/Library/Frameworks/GD.framework
rm -rf ~/Library/Developer/Xcode/Templates/Project\ Templates/Application/Window-based\ Good\ Dynamics\ Application.xctemplate
rm -rf ~/Library/Developer/Shared/Documentation/Docsets/com.good.gd.docset

# Uninstall the Xcode project templates...
GD_TEMPLATE_FILE=Single\ View\ Good\ Dynamics\ Application.xctemplate
GD_TEMPLATE_ASSETS_FILE=GDAssets.bundle

# Path to template project in Xcode6 has extra folder "iOS"
XCODE_APP=.app
if [[ "${SELECTED_SDK_DIR}" == *"$XCODE_APP"* ]]; then
	XCODE_APP_DIR=`expr "${SELECTED_SDK_DIR}" :  '\(.*\.app\)'`
else
	XCODE_APP_DIR="${SELECTED_SDK_DIR}"/Applications/Xcode.app
fi
if [ -d "${XCODE_APP_DIR}" ]; then
	#at some point 'version.plist' changed its name to begin with a lowercase 'v'
	#in a case-sensitive volume this makes a big difference
	VERSION_PLIST_CASE_SENSITIVE_NAME='version'
	if [ -f "${XCODE_APP_DIR}"/Contents/Version ]; then
		VERSION_PLIST_CASE_SENSITIVE_NAME='Version'
	fi
    
  XCODE_VER=`defaults read "${XCODE_APP_DIR}"/Contents/"${VERSION_PLIST_CASE_SENSITIVE_NAME}" CFBundleShortVersionString`
  echo Detected Xcode version ${XCODE_VER}
  if [ `expr ${XCODE_VER:0:1}` -ge 6 ] ; then
    echo Uninstalling Xcode templates for 6.x/7.x....
    SDK_TEMPLATE_DIR="${SDK_DIR}"OS.platform/Developer/Library/Xcode/Templates/Project\ Templates/iOS/Application

    rm -rf "${SDK_TEMPLATE_DIR}"/"${GD_TEMPLATE_FILE}"
    rm -rf "${SDK_TEMPLATE_DIR}"/"${GD_TEMPLATE_ASSETS_FILE}"
  else
    echo GD templates are only supported on Xcode 6.x or 7.x versions. Skipping template uninstallation.
  fi
fi

# Uninstall the API Reference documemtation...
GD_DOCSET_FILE=com.good.gd.docset
SDK_DOCSET_DIR="${SDK_DIR}"OS.platform/Developer/Documentation/Docsets
rm -rf "${SDK_DOCSET_DIR}"/"${GD_DOCSET_FILE}"
SDK_SYSTEM_DOCSET_DIR=~/Library/Developer/Shared/Documentation/DocSets
rm -rf "${SDK_SYSTEM_DOCSET_DIR}"/"${GD_DOCSET_FILE}"

# Uninstall GD.framework to from each iOS SDK...
GD_FRAMEWRK_FILE=GD.framework
SDK_FRAMEWRK_DIR=System/Library/Frameworks
for sub_dir in $(ls "${SDK_DEV_DIR}")
do
  rm -rf "${SDK_DEV_DIR}"/"${sub_dir}"/"${SDK_FRAMEWRK_DIR}"/"${GD_FRAMEWRK_FILE}"
done
for sub_dir in $(ls "${SDK_SIM_DIR}")
do
  rm -rf "${SDK_SIM_DIR}"/"${sub_dir}"/"${SDK_FRAMEWRK_DIR}"/"${GD_FRAMEWRK_FILE}"
done

echo Clean complete.
